from http.server import HTTPServer, BaseHTTPRequestHandler


class echoHandler(BaseHTTPRequestHandler):
def do_GET(self)
self.send_respone(200)
self.send_header("content-type", "text/html")
self.send_headers()
self.wfile.write(self.path(1:).encode())


def main():
PORT = 9004
server = HTTPServer(("", PORT), echoHandler)
print ("server running on PORT="%s % PORT)
server.serve_forever()


if_name_== '_main_'
main()
