import subprocess
import platform
import socket
import time
import os

path = 'C:/d'
host_name = socket.gethostname()
host_ip = socket.gethostbyname(host_name)
print("Cyber Terminal [Version 1.00]")
while True:
    code = input(">>> ")
    if code == 'list':
        dir_list = os.listdir(path)
        print("Files and Directories in '", path, "' :")
        print(dir_list)
    if code == 'dir':
        file = input("Enter The Direct File Path To Read: ")
        dir_list2 = os.listdir(file)
        print("Files and directories in '", file, "':")
        print(dir_list2)
    if code == 'help /all':
        print("dir- Reads Files and Directories.")